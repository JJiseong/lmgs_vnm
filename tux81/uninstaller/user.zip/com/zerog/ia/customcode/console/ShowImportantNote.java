/*
 * @(#)ShowImportantNote.java 0.9 10.02.2000
 *
 * MMA
 *
 */
package com.zerog.ia.customcode.console;

import com.zerog.ia.api.pub.*;

/**
 * <p>ShowImportantNote displays any important information that users should know before 
 * they continue with the installation</p>
 *
 * @version 1.0, 03 October 2000
 * @author Zero G
 */
public class ShowImportantNote extends CustomCodeConsoleAction
{
	//
	// The following are set before executeConsoleAction() is called.
	//
	// CustomCodeConsoleProxy cccp;

	//
	// The following provide static access to console input and output
	// 
	// IASys
	
	/**
	 * <p>This method gets called when the installer is ready to display the console 
	 * action.  Most, if not all, of the console input and output should orginate
	 * from the call into this action via this method.</p>
	 */
	public void executeConsoleAction() throws PreviousRequestException
	{
		//
		// Get the services that we will need
		//
		ConsoleUtils cu = (ConsoleUtils)cccp.getService(ConsoleUtils.class);
		InstallerResources ir = (InstallerResources)cccp.getService(InstallerResources.class);

		String bodyText = cccp.substitute("$SHOW_IMPORTANT_NOTE_BODY$");
		String prompt = cccp.substitute("$SHOW_IMPORTANT_NOTE_PROMPT$");
		
		//
		// if the text for elements of this step were not specified in an IA Variable, 
		// get the defaults from the installer's locale resources.
		//
		if (bodyText == null || bodyText.trim().equals(""))
		{
			bodyText = cccp.getValue("ImportantNoteUI.aboveLbl");
		}
		
		if (prompt == null || prompt.trim().equals(""))
		{
			prompt = cccp.getValue("ImportantNoteConsole.prompt");
		}
				
		cu.wprintln(bodyText);
		IASys.out.println();
		
		//
		// Show Important Note
		//
		cu.wprintlnWithBreaks(ir.getImportantNote());

		IASys.out.println();
		
		//
		// pause and wait for the user to press enter to continue.
		//
		cu.enterToContinue(prompt);
	}
	
	public String getTitle()
	{
		String title = cccp.substitute("$SHOW_IMPORTANT_NOTE_TITLE$");
		
		//
		// if a title was not specified in an IA Variable, get the default title 
		// from the installer's locale resources.
		//
		if (title == null || title.trim().equals(""))
		{
			title = cccp.getValue("ImportantNote.Title");
		}
		
		return title;
	}
}
