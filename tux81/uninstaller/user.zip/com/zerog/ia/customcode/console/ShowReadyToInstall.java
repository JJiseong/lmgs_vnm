/*
 * @(#)ShowReadyToInstall.java 0.9 10.23.2000
 *
 * MMA
 *
 */
package com.zerog.ia.customcode.console;

import com.zerog.ia.api.pub.*;

/**
 * <p>ShowReadyToInstall displays text informing the user that the installer is ready to
 * make physical changes to the installer.</p>
 *
 * @version 1.0, 23 October 2000
 * @author Zero G
 */
public class ShowReadyToInstall extends CustomCodeConsoleAction
{
	//
	// The following are set before executeConsoleAction() is called.
	//
	// CustomCodeConsoleProxy cccp;

	//
	// The following provide static access to console input and output
	// 
	// IASys
	
	/**
	 * <p>This method gets called when the installer is ready to display the console 
	 * action.  Most, if not all, of the console input and output should orginate
	 * from the call into this action via this method.</p>
	 */
	public void executeConsoleAction() throws PreviousRequestException
	{
		//
		// Get the services that we will need
		//
		ConsoleUtils cu = (ConsoleUtils)cccp.getService(ConsoleUtils.class);

		String bodyText = cccp.substitute("$SHOW_READY_TO_INSTALL_BODY$");
		String prompt = cccp.substitute("$SHOW_READY_TO_INSTALL_PROMPT$");
		String productName = cccp.substitute("$PRODUCT_NAME$");
		String installDir = cccp.substitute("$USER_INSTALL_DIR$");
		
		//
		// if the text for elements of this step were not specified in an IA Variable, 
		// get the defaults from the installer's locale resources.
		//
		if (bodyText == null || bodyText.trim().equals(""))
		{
			bodyText = cccp.getValue("ReadyToInstall.description1") 
						+ productName 
						+ cccp.getValue("ReadyToInstall.description2") 
						+ "\n\n   "
						+ installDir; 
		}
		
		if (prompt == null || prompt.trim().equals(""))
		{
			prompt = cccp.getValue("ReadyToInstall.prompt");
		}
				
		cu.wprintln(bodyText);
		IASys.out.println();
		
		//
		// pause and wait for the user to press enter to continue.
		//
		cu.enterToContinue(prompt);
	}
	
	/**
	 * <p>This method returns the String to be displayed on the installation
	 * step of which this Console action will be contained.</p>
	 */
	public String getTitle()
	{
		String title = cccp.substitute("$SHOW_READY_TO_INSTALL_TITLE$");
		
		//
		// if a title was not specified in an IA Variable, get the default title 
		// from the installer's locale resources.
		//
		if (title == null || title.trim().equals(""))
		{
			title = cccp.getValue("ReadyToInstall.title");
		}
		
		return title;
	}
}
