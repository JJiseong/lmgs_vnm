/*
 * @(#)ShowLicenseAgreement.java 0.9 10.02.2000
 *
 * MMA
 *
 */
package com.zerog.ia.customcode.console;

import com.zerog.ia.api.pub.*;

/**
 * <p>ShowLicenseAgreement displays a license agreement to the end user, requesting that
 * they agree to the license document.</p>
 *
 * <p>If the end user does not agree, the installer exits.  
 * Otherwise the installer continues.</p> 
 *
 * @version 1.0, 03 October 2000
 * @author Zero G
 */
public class ShowLicenseAgreement extends CustomCodeConsoleAction
{
	//
	// The following are set before executeConsoleAction() is called.
	//
	// CustomCodeConsoleProxy cccp;

	//
	// The following provide static access to console input and output
	// 
	// IASys
	
	/**
	 * <p>This method gets called when the installer is ready to display the console 
	 * action.  Most, if not all, of the console input and output should orginate
	 * from the call into this action via this method.</p>
	 */
	public void executeConsoleAction() throws PreviousRequestException
	{
		//
		// Get the services that we will need
		//
		ConsoleUtils cu = (ConsoleUtils)cccp.getService(ConsoleUtils.class);
		InstallerResources ir = (InstallerResources)cccp.getService(InstallerResources.class);

		String bodyText = cccp.substitute("$SHOW_LICENSE_AGREEMENT_BODY$");
		String prompt = cccp.substitute("$SHOW_LICENSE_AGREEMENT_PROMPT$");
		
		//
		// if the text for elements of this step were not specified in an IA Variable, 
		// get the defaults from the installer's locale resources.
		//
		if (bodyText == null || bodyText.trim().equals(""))
		{
			bodyText = cccp.getValue("LicenseAgrUI.aboveLbl");
		}
		
		if (prompt == null || prompt.trim().equals(""))
		{
			prompt = cccp.getValue("LicenseAgrUI.belowLbl").toUpperCase();
		}
				
		cu.wprintln(bodyText);
		IASys.out.println();
		
		//
		// Show License Agreement
		//
		cu.wprintlnWithBreaks(ir.getLicenseAgreement());

		IASys.out.println();
		
		//
		// Prompt the User to Agree to the License Agreement.
		//
		if(!cu.promptAndYesNoChoice(prompt))
		{
			//
			// if: the user did not agree to the license agreement, show
			//     a warning and prompt again.
			//
			IASys.out.println();
			cu.wprintln(cccp.getValue("LicenseAgrUI.dialog.warnLbl"));
			cu.wprintln(cccp.getValue("LicenseAgrUI.dialog.warnStr"));
			IASys.out.println();
			
			//
			// Prompt the User to again to agree to the License Agreement.
			//
			if(!cu.promptAndYesNoChoice(prompt))
			{
				//
				// if: the user still does not agree to the license agreement, 
				//     exit the installer.
				// 
				cccp.abortInstallation(0);
			}
		}
	}
	
	/**
	 * <p>This method returns the String to be displayed on the installation
	 * step of which this Console action will be contained.</p>
	 */
	public String getTitle()
	{
		String title = cccp.substitute("$SHOW_LICENSE_AGREEMENT_TITLE$");
		
		//
		// if a title was not specified in an IA Variable, get the default title 
		// from the installer's locale resources.
		//
		if (title == null || title.trim().equals(""))
		{
			title = cccp.getValue("LicenseAgr.Title");
		}
		
		return title;
	}
}
